package br.com.cellep.projetohack

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_cadastro.*

class CadastroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        //Criando o sharedPreferences
        val minhaPreferencia = getSharedPreferences("cadastro", Context.MODE_PRIVATE)
        //Criando o editor do sharedPreferences
        val meuEditor = minhaPreferencia.edit()

        btnCadastro.setOnClickListener {

            val nome = edtNome.text.toString().trim()
            val sobrenome = edtSobrenome.text.toString().trim()
            val email = edtEmail.text.toString().trim().toLowerCase()
            val senha = edtSenha.text.toString().trim()

            if (nome.isEmpty() || sobrenome.isEmpty() || email.isEmpty() || senha.isEmpty()){

                Toast.makeText(this@CadastroActivity, "Preencha todos os campos!",Toast.LENGTH_LONG).show()

            }
        }

    }
}
