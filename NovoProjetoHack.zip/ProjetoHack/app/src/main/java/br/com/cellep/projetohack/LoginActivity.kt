package br.com.cellep.projetohack

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //Criando o clique do botão entrar
        btnEntrar.setOnClickListener {
            //Recuperando os valores digitados
            val usuario = edtUsuario.text.toString().trim()
            val senha = edtSenha.text.toString().trim()

            //Condição para verificar se usuario ou senha estão corretos
            if (usuario.isEmpty()){
               //Usuario vazio
                txvResultado.text = "Usuário vazio!"
            }else if(senha.isEmpty()){
                //Senha vazia
                txvResultado.text = "Senha vazia!"
            }else if(usuario == "Adm"){
                if(senha == "1234"){
                    txvResultado.text = "Usuário logado!"
                }else{
                    //Senha incorreta
                    txvResultado.text = "Senha incorreta!"
                }
            }else{
                //Usuario incorreto
                txvResultado.text = "Usuario incorreto!"
            }
        }

        //Criando clique do botão cadastrar
        btnCadastro.setOnClickListener{

            startActivity(Intent(this@LoginActivity,CadastroActivity::class.java))

        }
    }
}
