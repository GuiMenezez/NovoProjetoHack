package br.com.cellep.projetohack

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        //Definido o tempo da splash
        Handler().postDelayed({
            //Abrindo a tela de login
            startActivity(Intent(this@SplashActivity, LoginActivity::class.java))
            //Finalizando a splash
            finish()
        }, 3000)
    }
}
